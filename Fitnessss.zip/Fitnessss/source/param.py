depth = 140
optimal_depth = 80

sigma1 = 1
sigma2 = 1
alpha_j=0.0016
alpha_a=0.006
beta_j=0.0000007
beta_a=0.000000075
gamma_j=0.00008
gamma_a=0.004
delta_j=0.000016
delta_a=0.00006